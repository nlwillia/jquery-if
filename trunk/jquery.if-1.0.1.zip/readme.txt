IF plugin for jQuery
Copyright � 2011 Todd Northrop
http://www.speednet.biz/

Last updated Match 7, 2011

This jQuery plugin adds conditional logic and branching to jQuery
matched set chaining.

Dual licensed under the MIT or GPL Version 2 licenses.
See mit-license.txt and gpl2-license.txt in the project root for details.

See changelog.txt for a summary of changes to the project.

Project page:
http://jquery-if.googlecode.com/

Please see the project page for all usage instructions and notes.

About the Author
	Todd Northrop is the owner and developer of Lottery Post, the
	world's largest community of lottery players and home to the
	#1 lottery results service worldwide. (www.lotterypost.com)
	He founded his company, Speednet Group, in 2000.

__
